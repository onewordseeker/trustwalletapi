const {
  Router
} = require("express");

const ethers = require('ethers');
const TronWeb = require('tronweb');
const mongoose = require("mongoose");
const queries = require("./database/queriesFunc");
const config = require('./config');

const app = Router();

// mainnet
var btcMain = require('./controllers/Bitcoin/index');
var ethMain = require("./controllers/Ethereum/eth");
var erc20Main = require("./controllers/Ethereum/erc20");
var apiServices = require("./database/services");

// testnet
var ethTest = require("./controllers/Testnet_Ethereum/eth");
var erc20Test = require("./controllers/Testnet_Ethereum/erc20");

// fantom
var fantomMainnet = require("./controllers/Fantom/eth");
var fantomERC20Mainnet = require("./controllers/Fantom/erc20");

// polygon
var polygonMainnet = require("./controllers/Polygon/eth");
var polygonERC20Mainnet = require("./controllers/Polygon/erc20");

// BSC
var bscMainnet = require("./controllers/BSC/eth");
var bscERC20Mainnet = require("./controllers/BSC/erc20");

// BSC
var avalancheMainnet = require("./controllers/Avalanche/eth");
var avalancheERC20Mainnet = require("./controllers/Avalanche/erc20");

// BSC
var cronosMainnet = require("./controllers/Cronos/eth");
var cronosERC20Mainnet = require("./controllers/Cronos/erc20");

app.use("/services", ensureWebToken, apiServices);

// mainnet server
app.use("/bitcoin/mainnet", ensureWebToken, btcMain);
app.use("/ether/mainnet", ensureWebToken, ethMain);
app.use("/token/mainnet", ensureWebToken, erc20Main);

// testnet
app.use("/ether/testnet", ensureWebToken, ethTest);
app.use("/token/testnet", ensureWebToken, erc20Test);

// Fantom Mainet
app.use("/fantom/mainnet", ensureWebToken, fantomMainnet);
app.use("/fantomToken/mainnet", ensureWebToken, fantomERC20Mainnet);

// Polygon Mainet
app.use("/polygon/mainnet", ensureWebToken, polygonMainnet);
app.use("/polygonToken/mainnet", ensureWebToken, polygonERC20Mainnet);

// BSC Mainet
app.use("/bsc/mainnet", ensureWebToken, bscMainnet);
app.use("/bscToken/mainnet", ensureWebToken, bscERC20Mainnet);

// Avalanche Mainet
app.use("/avalanche/mainnet", ensureWebToken, avalancheMainnet);
app.use("/avalancheToken/mainnet", ensureWebToken, avalancheERC20Mainnet);

// Cronos Mainet
app.use("/cronos/mainnet", ensureWebToken, cronosMainnet);
app.use("/cronosToken/mainnet", ensureWebToken, cronosERC20Mainnet);


app.get('/create-mnemonics-wallet', (req, res) => {
  try {
  console.log("ddd", req.query.numWallet)
  const mnemonic1 = ethers.utils.HDNode.entropyToMnemonic(
    ethers.utils.randomBytes(16),
  );

  const mnemonic = mnemonic1
  let walletList = []

  // the number of wallets to create
  const numWallets = req.query.numWallet;

  // create a HDNode instance from the mnemonic
  const hdNode = ethers.utils.HDNode.fromMnemonic(mnemonic);

  // derive wallets from the HDNode instance
  for (let i = 0; i < numWallets; i++) {
    const path = `m/44'/60'/0'/0/${i}`;
    const wallet = new ethers.Wallet(hdNode.derivePath(path).privateKey);
    walletList.push({ walletAddress: wallet.address, walletPrivateKey: wallet.privateKey })
    console.log(`Wallet ${i}: Address: ${wallet.address}, Private key: ${wallet.privateKey}`);
  }
  res.status(200).send({ message: "Wallet get successfully", mnemonics: mnemonic, wallet: walletList });
  } catch(e) {
    res.status(400).send({ 
        code: 400, 
        message: `Address creating stops with the error. ${e}`
    });
}
});


// Get Address From Mnemonics
app.get('/getaddress', async function(req, res){
  try {
    // const HttpProvider = TronWeb.providers.HttpProvider;
    // const fullNode = new HttpProvider("https://api.trongrid.io");
    // // const fullNode = new HttpProvider("http://192.168.1.162:8090");
    // const solidityNode = new HttpProvider("https://api.trongrid.io");
    // const eventServer = new HttpProvider("https://api.trongrid.io");
    // const tronWeb = new TronWeb(fullNode,solidityNode,eventServer);
    // console.log(fullNode);

    // // create new account
    // const account = tronWeb.createRandom({
    //   "mnemonic": {
    //     "phrase": "chimney cloth deny claim play rude love dose apart shove rack stone",
    //     "path": "m/44'/195'/0'/0/0",
    //     "locale": "en"
    //   },
    //   "privateKey": "0x79092289f3bfde55f079202e3642b2c4ba071d5f0b85d65b1919c8724e94848c",
    //   "publicKey": "0x0421c47d627bc2d856760dda17b42b726b4bc8f5def76aed0cbcd71566d0ffedfc3904c9c854854a5019b8373d2aed0c6b96ff5f3be07722403088742b0949a6c9",
    //   "address": "TEFAyPnainfiAJBuhExfMLJeHHxD2DZJmF",
    // });
    // console.log(account);
    // res.status(200).send({message: "Mnemonics are correct!", account: account});
    // return;
    let walletList = []
    
    const mnemonic = req.query.mnemonics;
    // console.log(mnemonic);
    // res.status(200).send({message: "Mnemonics are correct!"});
    const hdNode = ethers.utils.HDNode.fromMnemonic(mnemonic);
    let i = 0;
    const path = `m/44'/60'/0'/0/${i}`;
    const wallet = new ethers.Wallet(hdNode.derivePath(path).privateKey);
    walletList.push({ walletAddress: wallet.address, walletPrivateKey: wallet.privateKey });
    res.status(200).send({message: "Mnemonics are correct!", menomics: mnemonic, wallet: walletList});
  } catch(e) {
    res.status(400).send({ 
        code: 400, 
        message: `Address could not be fetched, error: ${e}`
    });
}
});

app.get("/", async function (request, response) {
  response.contentType("application/json");
  response.end(JSON.stringify("Node is running"));
});

app.use("/*", function (req, res) {
  return res.json({
    code: 404,
    data: null,
    msg: "Invalid Request 1 {URL Not Found}",
  });
});

async function ensureWebToken(req, res, next) {
  if(req.path !== '/createApi') {
  const x_access_token = req.headers["authorization"];
  if (typeof x_access_token !== undefined) {
    const query = await queries.checkApiExist(x_access_token);
      if (query[0] != x_access_token && query.toString() != "") {
        next();
      } else {
        res.sendStatus(403);
      }
      
    } else {
      res.sendStatus(403);
    }
  } else {
    const admin_key = config.admin.auth_key;
    const admin_password = config.admin.auth_password;

    const auth_key = req.body['auth_key'];
    const auth_password = req.body['auth_password'];
    if(admin_key == auth_key && admin_password == auth_password)
    next();
    else
    res.sendStatus(403);
  }
}

module.exports.routes = app;